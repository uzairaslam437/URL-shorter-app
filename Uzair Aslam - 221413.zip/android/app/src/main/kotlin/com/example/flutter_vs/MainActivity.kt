package com.example.flutter_vs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
