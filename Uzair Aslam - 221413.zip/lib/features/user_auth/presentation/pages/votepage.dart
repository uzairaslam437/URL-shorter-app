import 'package:flutter/material.dart';

class VotingPage extends StatefulWidget {
  @override
  _VotingPageState createState() => _VotingPageState();
}

class _VotingPageState extends State<VotingPage> {
  @override
  Widget build(BuildContext context) {
    // Define a common color for both buttons
    // final buttonColor = Colors.blue;

    return Scaffold(
      appBar: AppBar(
        title: Text('Voting Page'),
        actions: <Widget>[
          Center(
            child: Text('User ID: 12345'), // Center the user ID
          ),
          // Use a Column to stack the "Logout" text and the TextButton
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 10.0), // Add padding to the left
                child: TextButton(
                  onPressed: () {
                    // Navigate to the login page after clicking the logout button
                    Navigator.pushNamed(context, "/login");
                  },
                  child: Text('Logout',
                      style: TextStyle(
                          color: Colors
                              .white)), // Use white color for better contrast
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView(
        children: <Widget>[
          votingOption('PTI', 'assets/Pti.png'),
          votingOption('PMLN', 'assets/Pmln.png'),
          votingOption('PPP', 'assets/Ppp.png'),
        ],
      ),
    );
  }

  Widget votingOption(String name, String imagePath) {
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: <Widget>[
          Text(name,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          Image.asset(imagePath, height: 100, width: 100),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              // Implement your voting logic here
              print('Vote for $name');
              // Show a popup after voting
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text('Vote Casted!'),
                    content: Text('Thank You.'),
                    actions: <Widget>[
                      TextButton(
                        child: Text('OK'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  );
                },
              );
            },
            child: Text('Vote'),
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  Colors.blue, // Use the same blue color for the ElevatedButton
                  // onSurface: Colors.white, // Use white color for the text
            ),
          ),
        ],
      ),
    );
  }
}
